# MazeGenerator

This program allows you to create a custom maze, and try to complete it! Use the mouse in the settings menu and the arrow keys to navigate the maze

# How to Run:

Run any of the three python programs

Navigate to the folder in the terminal, and type

pip install pygame

python MazeSetupCode.py
