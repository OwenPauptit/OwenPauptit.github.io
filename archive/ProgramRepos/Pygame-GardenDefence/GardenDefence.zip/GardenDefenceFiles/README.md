# Garden Defence!

Basic tower defence game, use the mouse for almost all controls (drag and drop). Right click on save slots to rename them. Press escape on the keyboard to stop placing a tower if you want to. Towers can be upgraded by clicking on the tower, then the upgrade up arrow button and selecting the type of upgrade - range or power.



# To run:

navigate to the folder in the terminal, and type


  pip install pygame
  
  python main.py
